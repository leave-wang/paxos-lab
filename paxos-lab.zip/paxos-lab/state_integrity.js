const fs = require("node:fs");
const path = require("node:path");
const { isDeepStrictEqual } = require("node:util");

class StateIntegrity {
    constructor(filePath) {
        this.filePath = filePath;
        this.records = fs.existsSync(filePath)
            ? JSON.parse(fs.readFileSync(filePath, "utf8"))
            : {};
    }

    snapshot(acceptor) {
        return JSON.parse(JSON.stringify({
            highestPromised: acceptor.highestPromised,
            acceptedProposal: acceptor.acceptedProposal
        }));
    }

    validate(acceptor) {
        if (!Object.hasOwn(this.records, acceptor.id)) {
            // Only a genuinely empty node can be enrolled without a baseline.
            if (acceptor.highestPromised !== 0 ||
                acceptor.acceptedProposal !== null) {
                throw new Error(`${acceptor.id}: MISSING STATE BASELINE`);
            }
            return true;
        }
        if (!isDeepStrictEqual(this.snapshot(acceptor), this.records[acceptor.id])) {
            throw new Error(`${acceptor.id}: STATE LOSS OR MISMATCH DETECTED`);
        }
        return true;
    }

    record(acceptor) {
        const records = {
            ...this.records,
            [acceptor.id]: this.snapshot(acceptor)
        };
        fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
        const temporaryPath = `${this.filePath}.tmp`;
        fs.writeFileSync(temporaryPath, JSON.stringify(records, null, 2));
        fs.renameSync(temporaryPath, this.filePath);
        this.records = records;
    }
}

module.exports = StateIntegrity;
