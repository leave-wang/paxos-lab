class Quorum {
    constructor(size) {
        this.size = size;
        this.validateQuorum();
    }

    majority() {
        return Math.floor(this.size / 2) + 1;
    }

    validateQuorum() {
        if (!Number.isInteger(this.size) || this.size < 1) {
            throw new Error(`Invalid acceptor count: ${this.size}`);
        }

        const required = this.majority();
        const minimum = Math.floor(this.size / 2) + 1;

        if (
            !Number.isInteger(required) ||
            required < minimum ||
            required > this.size
        ) {
            throw new Error(
                `Unsafe quorum size: ${required}; expected ${minimum} to ${this.size}`
            );
        }

        return true;
    }

    reached(count) {
        this.validateQuorum();
        return count >= this.majority();
    }
}

module.exports = Quorum;