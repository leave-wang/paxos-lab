
const Quorum = require("./quorum");
const { randomUUID } = require("node:crypto");

class Simulator {

    constructor(proposer, acceptors, learners, { churnMonitor = null, auditLog = null } = {}) {

        this.proposer = proposer;
        this.churnMonitor = churnMonitor;
        this.auditLog = auditLog;
        this.acceptors = acceptors;
        this.learners = learners;

        this.quorum = new Quorum(acceptors.length);
    }

    checkHealth() {
        this.quorum.validateQuorum();
        const available = this.acceptors.filter(a => a.online === true).length;
        const required = this.quorum.majority();
        return {
            available,
            required,
            healthy: available >= required
        };
    }

    run(value) {
        const attemptId = randomUUID();
        const audit = (event, details = {}) => this.auditLog?.record(event, {
            ...details,
            attemptId,
            proposerId: this.proposer.id
        });
        audit("attempt_started", { requestedValue: value });
        try {
            return this.runAttempt(value, audit);
        } catch (error) {
            // A logger failure can also abort the attempt; do not claim success.
            audit("attempt_error", { message: error.message });
            throw error;
        }
    }

    runAttempt(value, audit) {
        const health = this.checkHealth();
        audit("health_checked", health);
        console.log(`HEALTH CHECK: ${health.available}/${this.acceptors.length} online; quorum ${health.required}`);

        if (!health.healthy) {
            console.log("BLOCKED: majority unavailable; no new proposal created");
            audit("attempt_blocked", { reason: "majority-unavailable" });
            return { status: "blocked", reason: "majority-unavailable" };
        }

        console.log("\n====================");
        console.log(`Proposal Value = ${value}`);
        console.log("====================");

        console.log(`Acceptors: ${this.acceptors.length}`);
        console.log(`Required Quorum: ${this.quorum.majority()}`);
        console.log("");

        const proposal = this.proposer.nextProposal(value);
        this.churnMonitor?.record(this.proposer.id, proposal.number);
        audit("proposal_created", { proposalNumber: proposal.number, value: proposal.value });

        /*
         * PREPARE
         */

        const promises = [];

        for (const acceptor of this.acceptors) {

            const response = acceptor.prepare(proposal.number);
            audit("prepare_response", {
                acceptorId: acceptor.id,
                proposalNumber: proposal.number,
                response: response?.type ?? "NO_RESPONSE",
                online: acceptor.online,
                acceptedProposal: response?.accepted ?? null
            });
            if (response) {
                promises.push(response);
                console.log(`${acceptor.id} PROMISE`);
            }
        }

        console.log(`Promises Received: ${promises.length}/${this.acceptors.length}`);

        const promiseQuorum = this.quorum.reached(promises.length);
        audit("quorum_checked", {
            phase: "prepare", count: promises.length,
            required: this.quorum.majority(), reached: promiseQuorum
        });
        if (!promiseQuorum) {
            audit("attempt_failed", { reason: "no-quorum-of-promises" });
            console.log("FAILED: no quorum of promises");
            return;
        }

        /*
         * PAXOS SAFETY RULE
         *
         * If any acceptor reports a previously
         * accepted value, continue proposing
         * the highest-numbered accepted value.
         */

        let highestAccepted = null;

        for (const promise of promises) {

            if (promise.accepted) {
                if (highestAccepted === null) {
                    highestAccepted = promise.accepted;

                } else if (promise.accepted.number > highestAccepted.number) {
                    highestAccepted = promise.accepted;
                }
            }
        }

        if (highestAccepted) {

            console.log("\nPREVIOUSLY ACCEPTED VALUE FOUND");
            console.log(`Proposal ${highestAccepted.number}`);

            console.log(`Value = ${highestAccepted.value}`);

            console.log("Overriding proposer value to preserve safety");

            audit("value_adopted", {
                proposalNumber: proposal.number,
                originalValue: proposal.value,
                value: highestAccepted.value,
                sourceProposalNumber: highestAccepted.number
            });
            proposal.value = highestAccepted.value;
        }

        /*
         * ACCEPT
         */

        const accepted = [];

        for (const acceptor of this.acceptors) {

            const response = acceptor.accept(proposal);
            audit("accept_response", {
                acceptorId: acceptor.id,
                proposalNumber: proposal.number,
                proposedValue: proposal.value,
                response: response?.type ?? "NO_RESPONSE",
                online: acceptor.online,
                acceptedProposal: response?.proposal ?? null
            });

            if (response) {
                accepted.push(response);
                console.log(`${acceptor.id} ACCEPTED`);
            }
        }

        console.log(`Acceptances Received: ${accepted.length}/${this.acceptors.length}`);

        const acceptQuorum = this.quorum.reached(accepted.length);
        audit("quorum_checked", {
            phase: "accept", count: accepted.length,
            required: this.quorum.majority(), reached: acceptQuorum
        });
        if (!acceptQuorum) {
            audit("attempt_failed", { reason: "no-quorum-of-accepts" });
            console.log("FAILED: no quorum of accepts");
            return;
        }

        /*
         * LEARN
         */

        audit("value_chosen", { proposalNumber: proposal.number, value: proposal.value });
        console.log(`VALUE CHOSEN: ${proposal.value}`);

        for (const learner of this.learners) {
            learner.learn(proposal.value);
            audit("learner_notified", { learnerId: learner.id, value: proposal.value });
        }
    }
}

module.exports = Simulator;