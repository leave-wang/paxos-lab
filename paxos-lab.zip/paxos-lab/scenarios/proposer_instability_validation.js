const assert = require("node:assert/strict");
const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const Simulator = require("../simulator");
const ProposerMonitor = require("../proposer_monitor");

function cluster() {
    let time = 0;
    let nextNumber = 101;
    const warnings = [];
    const monitor = new ProposerMonitor({
        now: () => time,
        onWarning: message => warnings.push(message)
    });
    const acceptors = ["A1", "A2", "A3"].map(id => new Acceptor(id));
    const learner = new Learner("L1");
    const proposers = [new Proposer("P1"), new Proposer("P2")];
    const simulators = proposers.map(proposer =>
        new Simulator(proposer, acceptors, [learner], { churnMonitor: monitor })
    );
    return {
        monitor, warnings, acceptors, learner,
        advance(milliseconds) { time += milliseconds; },
        run(index) {
            // The starter's independent counters can collide. Assign distinct
            // numbers here to isolate the monitoring experiment; this is not
            // a production distributed proposal-number generator.
            proposers[index].proposalNumber = nextNumber++ - 1;
            const originalLog = console.log;
            console.log = () => {};
            try {
                return simulators[index].run("instances=10");
            } finally {
                console.log = originalLog;
            }
        }
    };
}

console.log("TEST 1: One proposer submits frequently");
const stable = cluster();
for (let i = 0; i < 6; i++) { stable.run(0); stable.advance(100); }
assert.equal(stable.monitor.status().proposals, 6);
assert.equal(stable.monitor.status().switches, 0);
assert.equal(stable.monitor.status().unstable, false);
assert.equal(stable.warnings.length, 0);
assert.equal(stable.learner.value, "instances=10");
console.log("PASS: 6 proposals from P1; no instability warning");

console.log("\nTEST 2: P1 and P2 alternate rapidly");
const competing = cluster();
for (let i = 0; i < 6; i++) { competing.run(i % 2); competing.advance(100); }
assert.equal(competing.monitor.status().proposals, 6);
assert.equal(competing.monitor.status().switches, 5);
assert.equal(competing.monitor.status().unstable, true);
assert.equal(competing.warnings.length, 1);
assert.equal(competing.learner.value, "instances=10");
console.log(competing.warnings[0]);
console.log("PASS: 6 proposals and 5 switches; one warning; consensus still succeeds");

console.log("\nTEST 3: Old activity expires from the time window");
competing.advance(1001);
competing.run(0);
assert.equal(competing.monitor.status().proposals, 1);
assert.equal(competing.monitor.status().unstable, false);
assert.equal(competing.warnings.length, 1);
console.log("PASS: previous competition expired; current status is stable");

console.log("\nTEST 4: Slow proposer changes do not trigger the threshold");
const slow = cluster();
for (let i = 0; i < 6; i++) { slow.run(i % 2); slow.advance(1100); }
assert.equal(slow.warnings.length, 0);
assert.equal(slow.monitor.status().unstable, false);
console.log("PASS: widely spaced proposer changes produce no warning");

console.log("\nTEST 5: Majority-blocked requests are not counted as proposals");
const blocked = cluster();
blocked.acceptors[1].fail();
blocked.acceptors[2].fail();
assert.equal(blocked.run(0).status, "blocked");
assert.equal(blocked.monitor.status().proposals, 0);
console.log("PASS: blocked request produced no monitoring event");

console.log("\nALL PROPOSER MONITORING CHECKS PASSED");