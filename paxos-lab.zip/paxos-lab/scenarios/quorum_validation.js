const assert = require("node:assert/strict");
const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const Simulator = require("../simulator");

const proposer = new Proposer("P1");

const acceptors = ["A1", "A2", "A3", "A4", "A5"]
    .map(id => new Acceptor(id));

const learner = new Learner("L1");

const simulator = new Simulator(
    proposer,
    acceptors,
    [learner]
);

// Test 1: Reject an unsafe quorum.
console.log("TEST 1: Reject unsafe configuration before Prepare");

simulator.quorum.majority = () => 2;

assert.throws(
    () => simulator.run("instances=20"),
    /Unsafe quorum size/
);

// Verify that the rejected attempt changed no protocol state.
assert.equal(proposer.proposalNumber, 100);

for (const acceptor of acceptors) {
    assert.equal(acceptor.highestPromised, 0);
    assert.equal(acceptor.acceptedProposal, null);
}

assert.equal(learner.value, null);

console.log("PASS: quorum 2/5 blocked; protocol state unchanged");

// Test 2: Restore the original majority calculation.
console.log("\nTEST 2: Allow safe configuration");

delete simulator.quorum.majority;

simulator.run("instances=20");

assert.equal(simulator.quorum.majority(), 3);
assert.equal(learner.value, "instances=20");

console.log("PASS: quorum 3/5 allowed; learner received instances=20");