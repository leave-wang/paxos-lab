const assert = require("node:assert/strict");
const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const Simulator = require("../simulator");

const proposer = new Proposer("P1");
const acceptors = ["A1", "A2", "A3"].map(id => new Acceptor(id));
const learner = new Learner("L1");
const simulator = new Simulator(proposer, acceptors, [learner]);

function protocolState() {
    return JSON.stringify({
        proposalNumber: proposer.proposalNumber,
        acceptors: acceptors.map(a => ({
            id: a.id,
            highestPromised: a.highestPromised,
            acceptedProposal: a.acceptedProposal
        })),
        learnedValue: learner.value
    });
}

console.log("TEST 1: Block proposals when only one acceptor is online");
acceptors[1].fail();
acceptors[2].fail();
let before = protocolState();
assert.deepEqual(simulator.checkHealth(), {
    available: 1, required: 2, healthy: false
});
assert.equal(simulator.run("instances=10").status, "blocked");
assert.equal(protocolState(), before);
console.log("PASS: 1/3 online blocked; quorum remains 2; state unchanged");

console.log("\nTEST 2: Resume when a majority becomes available");
acceptors[1].recover();
assert.deepEqual(simulator.checkHealth(), {
    available: 2, required: 2, healthy: true
});
simulator.run("instances=10");
assert.equal(proposer.proposalNumber, 101);
assert.equal(learner.value, "instances=10");
assert.equal(acceptors[0].acceptedProposal.value, "instances=10");
assert.equal(acceptors[1].acceptedProposal.value, "instances=10");
assert.equal(acceptors[2].acceptedProposal, null);
console.log("PASS: 2/3 online allowed; consensus succeeded");

console.log("\nTEST 3: Recheck health on every new request");
acceptors[1].fail();
before = protocolState();
assert.equal(simulator.run("instances=20").status, "blocked");
assert.equal(protocolState(), before);
console.log("PASS: renewed majority loss blocked; previous decision preserved");

console.log("\nALL MAJORITY HEALTH CHECKS PASSED");
