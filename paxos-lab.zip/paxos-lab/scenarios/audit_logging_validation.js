const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const { randomUUID } = require("node:crypto");
const AuditLog = require("../audit_log");
const Proposer = require("../proposer");
const Acceptor = require("../acceptor");
const Learner = require("../learner");
const Simulator = require("../simulator");

const logPath = path.join(__dirname, "..", "logs", `audit-${randomUUID()}.jsonl`);
const logger = new AuditLog(logPath);
const proposer = new Proposer("P1");
const acceptors = ["A1", "A2", "A3"].map(id => new Acceptor(id));
const learner = new Learner("L1");
const simulator = new Simulator(proposer, acceptors, [learner], { auditLog: logger });
const read = () => fs.readFileSync(logPath, "utf8").trim().split("\n").map(JSON.parse);

function run(value) {
    const original = console.log;
    console.log = () => {};
    try { return simulator.run(value); }
    finally { console.log = original; }
}
function latestAttempt() {
    const records = read();
    const id = records.filter(r => r.event === "attempt_started").at(-1).attemptId;
    return records.filter(r => r.attemptId === id);
}

console.log("TEST 1: Record a successful consensus attempt");
run("instances=10");
let records = latestAttempt();
assert.ok(records.every(r => r.proposerId === "P1" && Number.isFinite(Date.parse(r.timestamp))));
assert.equal(records.find(r => r.event === "proposal_created").proposalNumber, 101);
assert.equal(records.filter(r => r.event === "prepare_response" && r.response === "PROMISE").length, 3);
assert.equal(records.filter(r => r.event === "accept_response" && r.acceptedProposal.value === "instances=10").length, 3);
assert.equal(records.filter(r => r.event === "quorum_checked" && r.reached && r.required === 2).length, 2);
assert.equal(records.find(r => r.event === "value_chosen").value, "instances=10");
assert.equal(records.at(-1).event, "learner_notified");
console.log("PASS: proposal, promises, acceptances, both quorums and chosen value recorded");

console.log("\nTEST 2: Explain why a requested value was replaced");
const firstAttempt = records[0].attemptId;
const firstRecords = JSON.stringify(records);
run("instances=20");
records = latestAttempt();
assert.notEqual(records[0].attemptId, firstAttempt);
assert.equal(records.find(r => r.event === "prepare_response").acceptedProposal.number, 101);
const adoption = records.find(r => r.event === "value_adopted");
assert.equal(adoption.originalValue, "instances=20");
assert.equal(adoption.value, "instances=10");
assert.equal(adoption.sourceProposalNumber, 101);
assert.equal(JSON.stringify(read().filter(r => r.attemptId === firstAttempt)), firstRecords);
console.log("PASS: inherited value and source proposal recorded; previous records unchanged");

console.log("\nTEST 3: Record a request blocked by majority loss");
acceptors[1].fail(); acceptors[2].fail();
assert.equal(run("instances=30").status, "blocked");
records = latestAttempt();
assert.equal(records.at(-1).event, "attempt_blocked");
assert.equal(records.some(r => r.event === "proposal_created" || r.event === "value_chosen"), false);
console.log("PASS: blocked reason recorded; no proposal or chosen-value event");

console.log("\nTEST 4: Record failure to obtain promises");
acceptors[1].recover(); acceptors[2].recover();
proposer.proposalNumber = 100; // Deliberately retry an obsolete number.
run("instances=40");
records = latestAttempt();
assert.equal(records.find(r => r.event === "quorum_checked").reached, false);
assert.equal(records.at(-1).reason, "no-quorum-of-promises");
assert.equal(records.some(r => r.event === "value_chosen"), false);
console.log("PASS: failed quorum recorded without a false success event");

console.log("\nTEST 5: Record a configuration error");
simulator.quorum.majority = () => 1;
assert.throws(() => run("instances=50"), /Unsafe quorum size/);
records = latestAttempt();
assert.equal(records.at(-1).event, "attempt_error");
assert.match(records.at(-1).message, /Unsafe quorum size/);
console.log("PASS: unsafe configuration error recorded");

console.log("\nTEST 6: Append without overwriting existing audit records");
const previousText = fs.readFileSync(logPath, "utf8");
new AuditLog(logPath).record("validation_completed", { tests: 6 });
assert.ok(fs.readFileSync(logPath, "utf8").startsWith(previousText));
assert.equal(read().at(-1).event, "validation_completed");
console.log("PASS: a new logger appended to the existing file");
console.log("\nALL AUDIT LOGGING CHECKS PASSED");
console.log(`AUDIT FILE: ${logPath}`);