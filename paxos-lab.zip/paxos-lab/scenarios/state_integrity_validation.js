const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const Acceptor = require("../acceptor");
const StateIntegrity = require("../state_integrity");

const directory = fs.mkdtempSync(path.join(os.tmpdir(), "paxos-state-check-"));
const filePath = path.join(directory, "expected-state.json");

try {
    const monitor = new StateIntegrity(filePath);
    const a1 = new Acceptor("A1", monitor);

    console.log("TEST 1: Allow a fresh node and record its history");
    assert.equal(monitor.validate(a1), true);
    assert.equal(a1.prepare(101).type, "PROMISE");
    assert.equal(a1.accept({ number: 101, value: "instances=10" }).type, "ACCEPTED");
    console.log("PASS: fresh node allowed; proposal 101 saved to baseline");

    console.log("\nTEST 2: Reload baseline and validate correctly restored state");
    const reloaded = new StateIntegrity(filePath);
    const restored = new Acceptor("A1", reloaded);
    restored.highestPromised = 101;
    restored.acceptedProposal = { number: 101, value: "instances=10" };
    assert.equal(reloaded.validate(restored), true);
    console.log("PASS: matching restored state allowed");

    console.log("\nTEST 3: Block an existing node that lost all its state");
    const lost = new Acceptor("A1", reloaded);
    const before = fs.readFileSync(filePath, "utf8");
    assert.throws(() => lost.prepare(102), /STATE LOSS OR MISMATCH/);
    assert.throws(
        () => lost.accept({ number: 102, value: "instances=20" }),
        /STATE LOSS OR MISMATCH/
    );
    assert.equal(lost.highestPromised, 0);
    assert.equal(lost.acceptedProposal, null);
    assert.equal(fs.readFileSync(filePath, "utf8"), before);
    console.log("PASS: Prepare and Accept blocked; trusted baseline unchanged");

    console.log("\nTEST 4: Detect loss of only the accepted proposal");
    restored.acceptedProposal = null;
    assert.throws(() => restored.prepare(102), /STATE LOSS OR MISMATCH/);
    assert.equal(restored.highestPromised, 101);
    assert.equal(fs.readFileSync(filePath, "utf8"), before);
    console.log("PASS: partial state loss blocked before a new promise");

    console.log("\nALL STATE INTEGRITY CHECKS PASSED");
} finally {
    fs.rmSync(directory, { recursive: true, force: true });
}
