const fs = require("node:fs");
const path = require("node:path");

class AuditLog {
    constructor(filePath) {
        this.filePath = filePath;
        fs.mkdirSync(path.dirname(filePath), { recursive: true });
    }

    record(event, details = {}) {
        const entry = {
            ...details,
            timestamp: new Date().toISOString(),
            event
        };
        // Serialize immediately so later changes cannot alter earlier records.
        fs.appendFileSync(this.filePath, JSON.stringify(entry) + "\n", "utf8");
    }
}

module.exports = AuditLog;