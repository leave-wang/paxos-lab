# Paxos Lab

**COMSM0122 — Fundamentals of System Security**  
**Workshop 3: Understanding and Stress-Testing Paxos**

A JavaScript learning simulator for exploring Paxos consensus, acceptor failures, competing proposers, value preservation, and the operational assumptions behind distributed agreement. The project includes the workshop scenarios and five hardening enhancements with dedicated validation scripts.

The simulator runs locally in a single Node.js process. It is an educational implementation, not a production distributed consensus service.

## Requirements

- Node.js 18 or newer
- npm

Check the installed versions:

```bash
node --version
npm --version
```

## Setup

Download or clone this repository, open a terminal in the project root, and run:

```bash
npm install
npm start
```

The project root is the directory containing `package.json`. The project currently declares no third-party dependencies; the implementation and validation scripts use Node.js built-in modules.

`npm start` runs the happy-path scenario.

## Project Structure

```text
paxos-lab/
├── package.json
├── package-lock.json
├── README.md
├── proposal.js
├── proposer.js
├── acceptor.js
├── learner.js
├── quorum.js
├── simulator.js
├── network.js
├── assumption_failures.js
├── state_integrity.js
├── proposer_monitor.js
├── audit_log.js
└── scenarios/
    ├── happy_path.js
    ├── acceptor_failure.js
    ├── competing_proposers.js
    ├── partial_acceptance.js
    ├── preserve_chosen_value.js
    ├── multi_paxos.js
    ├── network_partition.js
    ├── hardening.js
    ├── quorum_validation.js
    ├── state_integrity_validation.js
    ├── majority_health_validation.js
    ├── proposer_instability_validation.js
    ├── audit_logging_validation.js
    └── breaking_assumptions/
        ├── majority_loss.js
        ├── state_loss.js
        └── quorum_misconfiguration.js
```

The audit validation script also creates a `logs/` directory at runtime.

## Workshop Scenarios

Run each command from the project root.

| Part | Command | What to observe |
| --- | --- | --- |
| 1 — Understanding Consensus | `npm run happy` | Three acceptors form a quorum of two and choose `instances=10`. |
| 2 — Acceptor Failure | `npm run failure` | A3 is offline; A1 and A2 still form a quorum. |
| 3 — Competing Proposers | `npm run proposers` | Proposal 101 is rejected after promises for 102; proposal 102 is accepted. |
| 4 — Partial Acceptance | `npm run partial` | P2 discovers A1's accepted value and adopts `instances=10` after the scenario correction below. |
| 5 — Preserving Chosen Values | `npm run preserve` | The previously chosen `instances=12` is retained. |
| 6 — Stable Proposer Demonstration | `npm run multi` | P1 coordinates four rounds; all retain `instances=10`. |
| 7.1 — Network Partitioning | `npm run partition` | Message delivery stops during the simulated partition and resumes after repair. |
| 7.2 — Majority Loss | `npm run majority-loss` | With only one acceptor online, the enhanced simulator blocks the request before proposal creation. |
| 7.3 — State Loss | `npm run state-loss` | A1's promised and accepted state is explicitly cleared. |
| 7.4 — Quorum Misconfiguration | `npm run quorum-error` | A quorum of two out of five permits disjoint groups. |
| 8 — Original Hardening Demonstration | `npm run hardening` | Runs the supplied demonstrations; use the dedicated validation scripts to verify the enhancements. |

`npm run all` runs only the seven scenarios listed in the original package script: happy path, acceptor failure, competing proposers, partial acceptance, chosen-value preservation, stable proposer, and network partition. It does **not** run every failure scenario or the five hardening validation scripts.

### Part 4 Scenario Correction

In `scenarios/partial_acceptance.js`, P2's counter is set immediately after construction:

```javascript
const proposer = new Proposer("P2");
proposer.proposalNumber = 101;
```

`nextProposal()` increments the counter, so P2 now uses proposal number 102. A1 can then return a promise containing its previously accepted proposal `(101, instances=10)`.

In the supplied version, P2 reused number 101. A1 did not return a promise, and the run chose `instances=20`. The correction enables the intended demonstration; it does not implement globally unique proposal numbers for arbitrary competing proposers.

## Part 8: Hardening Enhancements

### 8.1 — Protect Quorum Rules

`Quorum.validateQuorum()` rejects invalid acceptor counts and quorum sizes. The required quorum must be an integer between a strict majority and the total configured acceptor count.

Validation occurs during Quorum construction, before each consensus attempt, and when checking response counts. An unsafe configuration is rejected before proposal generation or Prepare requests.

### 8.2 — Detect State Loss

`StateIntegrity` maintains an independent JSON baseline of each monitored acceptor's highest promised number and accepted proposal. A monitored acceptor checks its state before processing Prepare or Accept and updates the baseline after successful state changes.

This detects both complete state loss and loss of only the accepted proposal. It distinguishes an empty node with no baseline from an existing node whose empty state contradicts a stored baseline.

Enable it explicitly by supplying a monitor:

```javascript
const StateIntegrity = require("./state_integrity");
const Acceptor = require("./acceptor");

const stateMonitor = new StateIntegrity("./state/expected-state.json");
const acceptor = new Acceptor("A1", stateMonitor);
```

An existing node's state must be correctly restored before it resumes protocol processing. This component detects mismatches; it does not automatically restore state. If both the baseline and node state disappear, it cannot distinguish that node from a new one. Single-argument `Acceptor` construction remains supported without state monitoring.

### 8.3 — Protect Against Majority Loss

`Simulator.checkHealth()` compares the number of online acceptors with the quorum calculated from the full configured membership. Every `run()` call checks health before generating a proposal.

Insufficient availability returns a blocked status without changing protocol state. Recovery permits a subsequent request to proceed. The quorum is never reduced merely because acceptors are offline, and the original Prepare and Accept quorum checks remain in place.

### 8.4 — Detect Proposer Instability

`ProposerMonitor` records generated proposals within a sliding time window. Its default warning conditions are:

- At least five proposals within one second.
- At least two distinct proposer identities.
- At least three switches between adjacent proposer identities.

All conditions must hold. Repeated activity from one proposer alone does not trigger this warning. Old records expire, and repeated warnings are suppressed while the detected condition remains active.

Simulators must share a monitor to observe activity across their proposers. The detector reports potential instability; it does not elect a leader or stop proposals.

### 8.5 — Improve Observability

`AuditLog` appends structured JSONL records to a local file. Consensus attempts receive unique `attemptId` values, allowing related events to be grouped.

Recorded events include:

- Proposal creation and proposal numbers.
- Promise responses and reported accepted history.
- Acceptance responses and accepted proposals.
- Prepare and Accept quorum checks.
- Adoption of a previous value and its source proposal.
- Chosen values and learner notifications.
- Blocked requests, failed attempts, and exceptions.

Monitoring and logging can be enabled together using the optional fourth Simulator argument. In the following example, `proposer`, `acceptors`, and `learners` are the scenario's existing objects:

```javascript
const Simulator = require("./simulator");
const ProposerMonitor = require("./proposer_monitor");
const AuditLog = require("./audit_log");

const monitor = new ProposerMonitor();
const logger = new AuditLog("./logs/paxos.jsonl");

const simulator = new Simulator(proposer, acceptors, learners, {
    churnMonitor: monitor,
    auditLog: logger
});
```

The original three-argument constructor remains supported. State monitoring, proposer monitoring, and audit logging require explicit configuration; running `npm run hardening` does not automatically enable all three.

## Validate the Enhancements

Run all five scripts from the project root:

```bash
node scenarios/quorum_validation.js
node scenarios/state_integrity_validation.js
node scenarios/majority_health_validation.js
node scenarios/proposer_instability_validation.js
node scenarios/audit_logging_validation.js
```

Each script uses Node.js assertions. Successful checks print `PASS`; failed assertions terminate the script with an error.

| Validation script | Coverage |
| --- | --- |
| `quorum_validation.js` | Rejects 2/5 before protocol state changes; permits consensus with 3/5. |
| `state_integrity_validation.js` | Fresh node, matching restored state, complete state loss, and partial state loss. |
| `majority_health_validation.js` | Initial majority loss, recovery, and repeated majority loss after a decision. |
| `proposer_instability_validation.js` | Stable proposer, rapid alternation, window expiry, slow alternation, and exclusion of blocked requests. |
| `audit_logging_validation.js` | Successful consensus, value adoption, blocked requests, failed promises, configuration errors, and append behaviour. |

The state-integrity validation uses a temporary baseline that is removed after testing. The proposer-monitor validation uses a controlled clock and assigns distinct proposal numbers to isolate the monitoring behaviour.

The audit validation retains its output at `logs/audit-<unique-id>.jsonl` and prints the exact path. Open that file in a text editor to inspect the records. Every run creates a new file.

## Interpreting Results and Limitations

- **Safety and progress are different:** a blocked request need not represent an agreement violation. Known majority loss is now detected before Prepare; earlier workshop screenshots may show the original failure after collecting too few promises.
- **The Multi-Paxos scenario is simplified:** it repeatedly uses one proposer and the same accepted state. It has no separate log slots and repeats Prepare every round. It does not demonstrate leader election, convergence under competition, or the full Multi-Paxos optimisation.
- **The network scenario is separate:** it logs delivered and dropped messages without connecting the network simulator to the core consensus engine.
- **Several supplied scenarios are illustrative:** the state-loss and quorum-error scripts show changed state or possible disjoint groups rather than executing a complete conflicting-decision sequence.
- **Proposal numbering remains simplified:** independent proposers start with identical counters. The Part 4 correction and monitoring test setup do not provide a production distributed numbering scheme.
- **Health checks use local flags:** `online` does not establish real network reachability or guarantee that an acceptor will remain available throughout an attempt.
- **State protection requires a reliable baseline:** there is no automatic recovery, concurrent-writer coordination, or complete power-failure durability guarantee.
- **Monitoring uses thresholds:** it may miss other forms of instability, such as repeated retries by a single proposer. Its tests use sequential execution rather than concurrent distributed processes.
- **Audit logging is local:** there is no tamper protection or log rotation. Synchronous writes add overhead, logging errors can interrupt execution, and crashes may leave incomplete event sequences. Audit logs do not replace acceptor state storage.

## Experiment Report

The accompanying experiment report records the commands, screenshots, observations, explanations, and reflection answers for Parts 1–7. Part 8 records each enhancement's purpose, implementation, validation results, and remaining limitations.

Part 9 is an optional extension in the workshop manual. The work described in this README covers Parts 1–8.

## Acknowledgements

Based on the supplied COMSM0122 Paxos workshop starter project, whose `package.json` credits Inah Omoronyia. The scenario correction, hardening modules, and validation scripts extend that educational starting point.
