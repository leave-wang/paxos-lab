const { performance } = require("node:perf_hooks");

class ProposerMonitor {
    constructor({
        windowMs = 1000,
        minimumProposals = 5,
        minimumSwitches = 3,
        now = () => performance.now(),
        onWarning = message => console.warn(message)
    } = {}) {
        if (!Number.isFinite(windowMs) || windowMs <= 0 ||
            !Number.isInteger(minimumProposals) || minimumProposals < 2 ||
            !Number.isInteger(minimumSwitches) || minimumSwitches < 1) {
            throw new Error("Invalid proposer monitoring thresholds");
        }
        this.windowMs = windowMs;
        this.minimumProposals = minimumProposals;
        this.minimumSwitches = minimumSwitches;
        this.now = now;
        this.onWarning = onWarning;
        this.events = [];
        this.warningActive = false;
    }

    status(at = this.now()) {
        this.events = this.events.filter(event => event.time > at - this.windowMs);
        const proposerCount = new Set(this.events.map(event => event.proposerId)).size;
        let switches = 0;
        for (let i = 1; i < this.events.length; i++) {
            if (this.events[i].proposerId !== this.events[i - 1].proposerId) {
                switches++;
            }
        }
        const unstable = this.events.length >= this.minimumProposals &&
            proposerCount >= 2 && switches >= this.minimumSwitches;
        if (!unstable) this.warningActive = false;
        return { proposals: this.events.length, proposerCount, switches, unstable };
    }

    record(proposerId, proposalNumber) {
        const time = this.now();
        this.events.push({ time, proposerId, proposalNumber });
        const state = this.status(time);
        if (state.unstable && !this.warningActive) {
            this.warningActive = true;
            this.onWarning(
                `WARNING: potential proposer instability: ${state.proposals} proposals, ` +
                `${state.proposerCount} proposers, ${state.switches} switches ` +
                `within ${this.windowMs} ms`
            );
        }
        return state;
    }
}

module.exports = ProposerMonitor;